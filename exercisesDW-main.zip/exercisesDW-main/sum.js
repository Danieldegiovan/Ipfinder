import sum from './lib.js';

console.log(sum(2, 1)); //=> 3


console.log(sum(3, 2));
